# Fitnessstudio

Das Fitnessstudio _ProFit_ ist ein mittelgroßes Fitnessstudio in dem Herzen von Dresden.
Es erfreut sich großer Beliebtheit und hat eine große Anzahl an Mitgliedern.
Nun soll die Verwaltung des Studios digitalisiert werden, damit die Mitarbeiter und Mitglieder sich auf das Wesentliche konzentrieren können.
Dabei sollen verschiedene Geschäftsfelder berücksichtigt werden.

In der Mitarbeiterverwaltung können die Mitarbeiter des Fitnessstudios eingestellt, bearbeitet und entlassen werden. 
Die Mitarbeiter haben verschiedene Aufgaben/Rechte und Löhne. 
Ein Dienstplan muss ebenfalls erstellt werden, es muss zu jeder Zeit mind. eine Thekenkraft und ein Trainer anwesend sein. 
Am Abend muss eine Reinigungskraft für 1h eingetragen sein. 
Die Mitarbeiter sollen einen eigenen Login bekommen, um den Dienstplan zu betrachten und Urlaubsanträge zu stellen.

Es sollen ebenfalls alle Mitglieder verwaltet werden können. 
Diese können in dem Studio aufgenommen, bearbeitet und gekündigt werden. 
Bei der Aufnahme soll ein Login erstellt werden, damit der Kunde von zu Hause aus seinen nächsten Trainingstermin samt Trainingsplan nachschlagen kann, Rechnungen betrachten kann und um persönliche Daten zu ändern. 
Für jedes Mitglied kann ein individueller Trainingsplan durch den Trainer erstellt werden.\
Wirbt ein Mitglied ein neues Mitglied an, wird ihm ein bestimmter Betrag auf sein Kundenkonto gutgeschrieben, welches er nur an der Theke verbrauchen kann und nicht ausgezahlt wird. \
Kunden, die zum ersten Mal das Studio besuchen, können mit einem Trainer ein Probetraining vereinbaren, entweder direkt im Studio oder über das Internetportal des Studios. 
Eine Mitgliedschaft kostet eine monatliche Gebühr und kann pro Jahr für einen Monat ohne Gründe ausgesetzt werden. 
Am Ende des Monats wird für jeden Kunden eine Rechnung über sein Kundenkonto erstellt.

Des Weiteren gibt es einen Eingangs- und Verkaufsbereich. 
An der Theke können auch Getränke, Nahrungsergänzungsmittel oder Zubehör erworben werden, diese werden bar bezahlt oder direkt vom Kundenkonto abgebucht.
Die Artikel des Verkaufsbereiches müssen sich ebenfalls verwalten lassen. 
Es müssen Artikel hinzugefügt, bearbeitet und gelöscht werden können. 
Beim Unterschreiten der Mindestmenge müssen die Artikel für den Angestellten markiert werden. 
Artikel die für den Verzehr gedacht sind, haben ein Verfallsdatum, welches regelmäßig überprüft werden soll. 
Für verschiedene Artikel soll man feinen Rabatt angeben können.

Ebenfalls sollen Statistiken über laufende Kosten, Einnahmen, Kundenverhalten und Verkaufsartikel dargestellt werden.
Verschiedene Einstellungen wie Vertragslaufzeit, monatliche Gebühren, Neuwerbungsprämie, Öffnungszeiten usw. sollen sich einfach global verändern lassen.