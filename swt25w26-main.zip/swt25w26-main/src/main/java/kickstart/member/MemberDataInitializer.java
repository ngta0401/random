package kickstart.member;

import java.time.LocalDate;
import java.util.List;

import org.salespointframework.core.DataInitializer;
import org.salespointframework.useraccount.Password.UnencryptedPassword;
import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccountManagement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

/**
 * Initializes default user accounts and members. The following are created:
 * <ul>
 * <li>An admin user named "boss".</li>
 * <li>The members "hans", "dextermorgan", "earlhickey", "mclovinfogell" backed by user accounts with the same
 * name.</li>
 * </ul>
 *
 * @author Oliver Gierke
 */
@Component
@Order(10)
class MemberDataInitializer implements DataInitializer {

	private static final Logger LOG = LoggerFactory.getLogger(MemberDataInitializer.class);

	private final UserAccountManagement userAccountManagement;
	private final MemberManagement memberManagement;

	/**
	 * Creates a new {@link MemberDataInitializer} with the given {@link UserAccountManagement} and
	 * {@link MemberRepository}.
	 *
	 * @param userAccountManagement must not be {@literal null}.
	 * @param memberManagement must not be {@literal null}.
	 */
	MemberDataInitializer(UserAccountManagement userAccountManagement, MemberManagement memberManagement) {

		Assert.notNull(userAccountManagement, "UserAccountManagement must not be null!");
		Assert.notNull(memberManagement, "MemberRepository must not be null!");

		this.userAccountManagement = userAccountManagement;
		this.memberManagement = memberManagement;
	}

	/*
	 * (non-Javadoc)
	 * @see org.salespointframework.core.DataInitializer#initialize()
	 */
	@Override
	public void initialize() {

		// Skip creation if database was already populated
		if (userAccountManagement.findByUsername("boss").isPresent()) {
			return;
		}

		LOG.info("Creating default users and members.");

		userAccountManagement.create("boss",
			UnencryptedPassword.of("Pass_123"),
			"boss@profit.de",
			Role.of("CHEF"));

		userAccountManagement.create("counterstaff",
			UnencryptedPassword.of("Pass_123"),
			"counterstaff@profit.de",
			Role.of("COUNTERSTAFF"));

		userAccountManagement.create("trainer",
			UnencryptedPassword.of("Pass_123"),
			"trainer@profit.de",
			Role.of("TRAINER"));

		userAccountManagement.create("cleaner",
			UnencryptedPassword.of("Pass_123"),
			"cleaner@profit.de",
			Role.of("CLEANER"));

		userAccountManagement.create("gast",
			UnencryptedPassword.of("Pass_123"),
			"GAST@profit.de",
			Role.of("GAST"));




		var password = "Pass_123";
		var passwordConfirm= "Pass_123";

		List.of(//
			new RegistrationForm("hans", "Hans", "Müller", password, passwordConfirm,
				LocalDate.of(1990, 5, 15), "hans.mueller@email.com", "Dresden"),

			new RegistrationForm("anna", "Anna", "Schmidt", password, passwordConfirm,
				LocalDate.of(1985, 8, 22), "anna.schmidt@email.com", "Dresden"),

			new RegistrationForm("peter", "Peter", "Weber", password, passwordConfirm,
				LocalDate.of(1992, 3, 10), "peter.weber@email.com", "Dresden"),

			new RegistrationForm("maria", "Maria", "Fischer", password, passwordConfirm,
				LocalDate.of(1988, 11, 30), "maria.fischer@email.com", "Dresden")

		).forEach(memberManagement::createMember);
	}
}


