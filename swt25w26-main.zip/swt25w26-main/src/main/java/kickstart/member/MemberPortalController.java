package kickstart.member;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MemberPortalController {
	@GetMapping("/memberportal")
	public String index() {
		return "memberportal";
	}

}
