package kickstart.member;

import org.salespointframework.useraccount.Password.UnencryptedPassword;
import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccountManagement;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import java.util.List;
import java.util.Optional;
/**
 * Implementation of business logic related to {@link Member}s.
 *
 * @author Oliver Gierke
 */
@Service
@Transactional
public class MemberManagement {

	public static final Role MEMBER_ROLE = Role.of("MEMBER");

	private final MemberRepository members;
	private final UserAccountManagement userAccounts;

	/**
	 * Creates a new {@link MemberManagement} with the given {@link MemberRepository} and
	 * {@link UserAccountManagement}.
	 *
	 * @param members must not be {@literal null}.
	 * @param userAccounts must not be {@literal null}.
	 */
	MemberManagement(MemberRepository members, UserAccountManagement userAccounts) {

		Assert.notNull(members, "MemberRepository must not be null!");
		Assert.notNull(userAccounts, "UserAccountManagement must not be null!");

		this.members = members;
		this.userAccounts = userAccounts;
	}

	/**
	 * Creates a new {@link Member} using the information given in the {@link RegistrationForm}.
	 *
	 * @param form must not be {@literal null}.
	 * @return the new {@link Member} instance.
	 */
	public Member createMember(RegistrationForm form) {

		Assert.notNull(form, "Registration form must not be null!");

		var password = UnencryptedPassword.of(form.getPassword());
		var userAccount = userAccounts.create(
			form.getName(),
			password,
			form.getEmail(),
			MEMBER_ROLE);

		return members.save(new Member(
			userAccount,
			form.getFirstname(),
			form.getLastname(),
			form.getEmail(),
			form.getMemberbirthday(),
			form.getAddress()));
	}


	public void updateMember(Member member) {
		members.save(member);
	}


	@Transactional
	public void deleteMember(String username) {
		userAccounts.findByUsername(username).ifPresent(userAccount -> {

			List<Role> rolesToRemove = userAccount.getRoles().toList();
			rolesToRemove.forEach(userAccount::remove);

			// Save the user account without roles first
			userAccounts.save(userAccount);


			members.findByUserAccount(userAccount).ifPresent(member -> {
				members.delete(member);
			});


			userAccounts.delete(userAccount);
		});
	}

	/**
	 * Returns all {@link Member}s currently available in the system.
	 *
	 * @return all {@link Member} entities.
	 */
	public Streamable<Member> findAll() {
		return members.findAll();
	}

	public Optional<Member> findByName(String name) {
		return userAccounts.findByUsername(name)
			.flatMap(userAccount -> members.findByUserAccount(userAccount));
	}
}

