package kickstart.member;

import jakarta.persistence.Embeddable;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToOne;
import kickstart.member.Member.MemberIdentifier;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.UUID;

import org.jmolecules.ddd.types.Identifier;
import org.salespointframework.core.AbstractAggregateRoot;
import org.salespointframework.useraccount.UserAccount;

// (｡◕‿◕｡)
// Salespoint bietet nur eine UserAccount Verwaltung, für weitere Attribute sollte eine extra
// Klasse geschrieben werden. Unser Kunde hat noch eine Adresse, das bietet der UserAccount nicht.
// Um den Member in die Datenbank zu bekommen, schreiben wir ein MemberRepository.

@Entity
public class Member extends AbstractAggregateRoot<MemberIdentifier> {

	private @EmbeddedId MemberIdentifier id = new MemberIdentifier();

	private String address;
	private String name;
	private String firstname;
	private String lastname;
	private String email;
	private LocalDate memberbirthday;

	// (｡◕‿◕｡)
	// Jedem Member ist genau ein UserAccount zugeordnet, um später über den UserAccount an den
	// Member zu kommen, speichern wir den hier
	@OneToOne //
	private UserAccount userAccount;

	@SuppressWarnings("unused")
	public Member() {}

	public Member(UserAccount userAccount, String address) {
		this.userAccount = userAccount;
		this.address = address;
	}

	public Member(UserAccount userAccount, String firstname, String lastname,
				   String email, LocalDate memberbirthday, String address){
		this.userAccount = userAccount;
		this.firstname = firstname;
		this.lastname = lastname;
		this.address = address;
		this.email = email;
		this.memberbirthday = memberbirthday;
	}

	private int birthyear;


	public Member(String name, String email, int birthyear){

        this.name = name;
        this.email = email;
        this.birthyear = birthyear;
    }

	/*
	 * (non-Javadoc)
	 * @see org.springframework.data.domain.Persistable#getId()
	 */
	@Override
	public MemberIdentifier getId() {
		return id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getName(){
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBirthyear() {
		return birthyear;
	}

	public void setBirthyear(int birthyear) {
		this.birthyear = birthyear;
	}
	public UserAccount getUserAccount() {
		return userAccount;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getMemberbirthday() {
		return memberbirthday;
	}

	public void setMemberbirthday(LocalDate memberbirthday) {
		this.memberbirthday = memberbirthday;
	}


	@Embeddable
	public static final class MemberIdentifier implements Identifier, Serializable {

		private static final long serialVersionUID = 7740660930809051850L;
		private final UUID identifier;

		/**
		 * Creates a new unique identifier for {@link Member}s.
		 */
		MemberIdentifier() {
			this(UUID.randomUUID());
		}

		/**
		 * Only needed for property editor, shouldn't be used otherwise.
		 *
		 * @param identifier The string representation of the identifier.
		 */
		MemberIdentifier(UUID identifier) {
			this.identifier = identifier;
		}

		/*
		 * (non-Javadoc)
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {

			final int prime = 31;
			int result = 1;

			result = prime * result + (identifier == null ? 0 : identifier.hashCode());

			return result;
		}

		/*
		 * (non-Javadoc)
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) {

			if (obj == this) {
				return true;
			}

			if (!(obj instanceof MemberIdentifier that)) {
				return false;
			}

			return this.identifier.equals(that.identifier);
		}
	}
}
