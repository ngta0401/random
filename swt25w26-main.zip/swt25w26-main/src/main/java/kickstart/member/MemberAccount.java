package kickstart.member;

import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Optional;

@Controller
public class MemberAccount {

	private final MemberManagement memberManagement;

	public MemberAccount(MemberManagement memberManagement) {this.memberManagement = memberManagement;}

		@GetMapping("/account")
		public String viewAccount(Model model,
								  org.springframework.security.core.Authentication authentication) {
			if (authentication == null || !authentication.isAuthenticated()) {
				return "redirect:/login";
			}

			String username = authentication.getName();
			Optional<Member> memberOpt = memberManagement.findByName(username);

			if (memberOpt.isPresent()) {
				model.addAttribute("memberForm", memberOpt.get());
				return "account";
			} else {
				return "redirect:/";
			}
		}

		@GetMapping("/editaccount")
		public String editAccount(Model model,
								  org.springframework.security.core.Authentication authentication) {
			if (authentication == null || !authentication.isAuthenticated()) {
				return "redirect:/login";
			}

			String username = authentication.getName();
			Optional<Member> memberOpt = memberManagement.findByName(username);

			if (memberOpt.isPresent()) {
				model.addAttribute("memberForm", memberOpt.get());
				return "editaccount";
			} else {
				return "redirect:/";
			}
		}


	@PostMapping("/account")
	public String updateAccount(@ModelAttribute("memberForm") Member editedMember,
								org.springframework.security.core.Authentication authentication) {

		if (authentication == null || !authentication.isAuthenticated()) {
			return "redirect:/login";
		}

		String username = authentication.getName();
		Optional<Member> existingMemberOpt = memberManagement.findByName(username);

		if (existingMemberOpt.isPresent()) {
			Member existingMember = existingMemberOpt.get();

			existingMember.setFirstname(editedMember.getFirstname());
			existingMember.setLastname(editedMember.getLastname());
			existingMember.setEmail(editedMember.getEmail());
			existingMember.setMemberbirthday(editedMember.getMemberbirthday());
			existingMember.setAddress(editedMember.getAddress());

			memberManagement.updateMember(existingMember);
		}

		return "redirect:/account?success";
	}

}
