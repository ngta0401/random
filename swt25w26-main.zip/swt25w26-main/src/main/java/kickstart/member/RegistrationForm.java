package kickstart.member;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;

import jakarta.validation.constraints.Pattern;
import org.springframework.validation.Errors;
import jakarta.validation.constraints.AssertTrue;

import java.time.LocalDate;


/**
 * This is a so called form-backing class to prepare the form display (in
 * {@link CustomerController#register(org.springframework.ui.Model, RegistrationForm)}) and during form submission (in
 * {@link CustomerController#registerNew(RegistrationForm, Errors)}.
 * <p>
 * The latter will have the form data bound to constructor of this class and the {@link Valid} annotation on the
 * controller method parameter will cause the validation annotation on the fields being triggered. For invalid values,
 * the {@link Errors} instance gets a field error registered and a couple of internationalization codes registered that
 * Spring will try to resolve against the messages declared in {@code messages.properties}.
 * <p>
 * The codes will look as follows:
 * <ul>
 * <li>{@code $SimpleAnnotationName.$SimpleBeanTypeName.$propertyName} - e.g.
 * {@code NotEmpty.registrationForm.name}</li>
 * <li>{@code $SimpleAnnotationName.$propertyName} - e.g. {@code NotEmpty.name}</li>
 * <li>{@code $SimpleAnnotationName.$fullyQualifiedTypeName} - e.g. {@code NotEmpty.java.lang.String}</li>
 * <li>{@code $SimpleAnnotationName} – e.g. {@code NotEmpty}</li>
 * </ul>
 * This allows you to declare generic error messages for based on the problem rejected but also very specific ones for
 * the particular binding type and field.
 * <p>
 * Advanced validations can be implemented by declaring custom validation methods on the form-backing class, evaluating
 * the state and manually rejecting field values (see {@link #validate(Errors)}).
 *
 * @author Paul Henke
 * @author Oliver Drotbohm
 */
class RegistrationForm {


	private final @NotEmpty String name;
	private final @NotEmpty String firstname;
	private final @NotEmpty String lastname;

	@Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$",
		message = "Das Passwort muss mindestens 8 Zeichen lang sein und Großbuchstaben, Kleinbuchstaben und Zahlen enthalten")
	private final String password;

	private final @NotEmpty String passwordConfirm;
	private final @NotEmpty String address;
	private final LocalDate memberbirthday;

	@NotEmpty(message = "Die E-Mail-Adresse darf nicht leer sein")
	@Email(message = "Die E-Mail-Adresse ist nicht gültig")
	private final String email;

	public RegistrationForm(String name, String firstname, String lastname, String password,
							String passwordConfirm, LocalDate memberbirthday, String email, String address) {
		this.name = name;
		this.firstname = firstname;
		this.lastname = lastname;
		this.password = password;
		this.passwordConfirm = passwordConfirm;
		this.memberbirthday = memberbirthday;
		this.email = email;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public String getPassword() {
		return password;
	}

	public String getFirstname() {
		return firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public String getPasswordConfirm() {return passwordConfirm; }

	public String getAddress() {
		return address;
	}

	public LocalDate getMemberbirthday() {
		return memberbirthday;
	}

	public String getEmail() {
		return email;
	}

	@AssertTrue(message = "Passwörter müssen übereinstimmen")
	public boolean isPasswordMatching() {
		return password != null && password.equals(passwordConfirm);
	}

	public void validate(Errors errors, MemberManagement memberManagement) {
		// Complex validation goes here
		if (memberManagement.findByName(name).isPresent()) {
			errors.rejectValue("name", "name.duplicate", "Der Name ist bereits vergeben");
		}
	}
}
