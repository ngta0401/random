package kickstart.member;

import kickstart.member.Member.MemberIdentifier;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.util.Streamable;
import org.salespointframework.useraccount.UserAccount;
import java.util.Optional;

/**
 * A repository interface to manage {@link Member} instances.
 *
 * @author Paul Henke
 * @author Oliver Gierke
 */
interface MemberRepository extends CrudRepository<Member, MemberIdentifier> {

	/**
	 * Re-declared {@link CrudRepository#findAll()} to return a {@link Streamable} instead of {@link Iterable}.
	 */
	@Override
	Streamable<Member> findAll();

	Optional<Member> findByUserAccount(UserAccount userAccount);
}