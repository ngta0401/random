package kickstart.member;

import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@Controller
public class MemberManagementController {

	private final MemberManagement memberManagement;

	public MemberManagementController(MemberManagement memberManagement) {
		this.memberManagement = memberManagement;
	}

	@GetMapping("/membermanagement")
	public String listMembers(@RequestParam(value = "editName", required = false) String editName, Model model){

		Member newMember = new Member();

		if (editName != null) {

			Optional<Member> memberOpt = memberManagement.findByName(editName);
			if (memberOpt.isPresent()) {
				newMember = memberOpt.get();
			}
		}

		model.addAttribute("members", memberManagement.findAll());
		model.addAttribute("memberForm", newMember);

		return "membermanagement";
	}

	@GetMapping("/editmember")
	public String showEditMemberForm(@RequestParam("editName") String name, Model model) {

		Member memberToEdit = memberManagement.findByName(name)
			.orElse(null);

		if (memberToEdit == null) {
			return "redirect:/membermanagement";
		}

		model.addAttribute("memberForm", memberToEdit);
		return "editmember";
	}

	@PostMapping("/editmember")
	public String updateMember(@ModelAttribute("memberForm") Member editedMember,
							   @RequestParam("username") String username) {

		Optional<Member> existingMemberOpt = memberManagement.findByName(username);

		if (existingMemberOpt.isPresent()) {
			Member existingMember = existingMemberOpt.get();


			existingMember.setFirstname(editedMember.getFirstname());
			existingMember.setLastname(editedMember.getLastname());
			existingMember.setEmail(editedMember.getEmail());
			existingMember.setMemberbirthday(editedMember.getMemberbirthday());
			existingMember.setAddress(editedMember.getAddress());


			memberManagement.updateMember(existingMember);
		}

		return "redirect:/membermanagement";
	}

	@PostMapping("/membermanagement/delete")
	public String deleteMember(@RequestParam("deleteName") String deleteName) {
		// Gọi method delete từ MemberManagement
		memberManagement.deleteMember(deleteName);
		return "redirect:/membermanagement";
	}

	@GetMapping("/addmember")
	public String showAddMemberForm(Model model) {
		model.addAttribute("memberForm", new Member());
		return "addmember";
	}


}