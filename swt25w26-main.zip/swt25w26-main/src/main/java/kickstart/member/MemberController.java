package kickstart.member;

import jakarta.validation.Valid;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
class MemberController {

	private final MemberManagement memberManagement;

	MemberController(MemberManagement memberManagement) {

		Assert.notNull(memberManagement, "MemberManagement must not be null!");

		this.memberManagement = memberManagement;
	}

	// (｡◕‿◕｡)
	// Über @Valid können wir die Eingaben automagisch prüfen lassen, ob es Fehler gab steht im BindingResult,
	// dies muss direkt nach dem @Valid Parameter folgen.
	// Siehe außerdem videoshop.model.validation.RegistrationForm
	// Lektüre: http://docs.spring.io/spring/docs/current/spring-framework-reference/html/validation.html
	@PostMapping("/register")
	String registerNew(@Valid RegistrationForm form, Errors result) {

		form.validate(result, memberManagement);

		if (result.hasErrors()) {
			return "register";
		}

		// (｡◕‿◕｡)
		// Falles alles in Ordnung ist legen wir einen Member an
		memberManagement.createMember(form);

		return "redirect:/";
	}

	@GetMapping("/register")
	String register(Model model, RegistrationForm form) {
		return "register";
	}

	@GetMapping("/members")
	@PreAuthorize("hasRole('BOSS')")
	String members(Model model) {

		model.addAttribute("memberList", memberManagement.findAll());

		return "members";
	}


}
