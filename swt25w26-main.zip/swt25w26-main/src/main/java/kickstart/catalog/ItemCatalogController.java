package kickstart.catalog;

import org.salespointframework.inventory.UniqueInventory;
import org.salespointframework.inventory.UniqueInventoryItem;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ItemCatalogController {

    private final ItemCatalog catalog;
    private final UniqueInventory<UniqueInventoryItem> inventory;

    ItemCatalogController(ItemCatalog catalog,UniqueInventory<UniqueInventoryItem> inventory) {
        this.catalog = catalog;
        this.inventory = inventory;
    }

    @GetMapping("/catalog")
    String catalog(Model model) {
        model.addAttribute("catalog", catalog.findByType(Item.ItemType.SUBSCRIPTION));
        model.addAttribute("inventory", inventory.findAll());
        return "catalog";
    }
}