package kickstart.catalog;

import java.time.LocalDate;
import java.util.Optional;

import org.javamoney.moneta.Money;
import static org.salespointframework.core.Currencies.EURO;
import org.salespointframework.core.DataInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import kickstart.catalog.Item.ItemType;

@Component
@Order(10)
public class ItemCatalogDataInitializer implements DataInitializer {
    
    private static final Logger LOG = LoggerFactory.getLogger(ItemCatalogDataInitializer.class);
    private final ItemCatalog itemCatalog;
    public ItemCatalogDataInitializer(ItemCatalog itemCatalog) {
    
        Assert.notNull(itemCatalog, "ItemCatalog must not be null!");
        this.itemCatalog = itemCatalog;
    }

    @Override
    public void initialize() {

        if (itemCatalog.findAll().isEmpty()){

            LOG.info("Initializing Catalog with sample data.");

            itemCatalog.save(new Item("Apfel", Money.of(1.00, EURO), ItemType.FOOD, Optional.of(LocalDate.of(2025, 12, 31)), Optional.empty()));
            itemCatalog.save(new Item("Proteinriegel", Money.of(2.50, EURO), ItemType.FOOD, Optional.of(LocalDate.of(2027, 7, 15)), Optional.empty()));
            itemCatalog.save(new Item("Apfelsaft", Money.of(1.80, EURO), ItemType.FOOD, Optional.of(LocalDate.of(2026, 8, 10)), Optional.empty()));
            itemCatalog.save(new Item("Wasserflasche", Money.of(1.20, EURO), ItemType.FOOD, Optional.of(LocalDate.of(2027, 1, 1)), Optional.empty()));
            itemCatalog.save(new Item("Energy Drink", Money.of(2.50, EURO), ItemType.FOOD, Optional.of(LocalDate.of(2026, 9, 5)), Optional.empty()));
            itemCatalog.save(new Item("Yoga Matte", Money.of(20.00, EURO), ItemType.OTHERS, Optional.empty(), Optional.empty()));
            itemCatalog.save(new Item("Pro-Fit Dresden Handtuch", Money.of(7.00, EURO), ItemType.OTHERS, Optional.empty(), Optional.empty()));
            itemCatalog.save(new Item("Pro-Fit Dresden Shaker", Money.of(6.50, EURO), ItemType.OTHERS, Optional.empty(), Optional.empty()));
            itemCatalog.save(new Item("Standard-Abo", Money.of(30.00, EURO), ItemType.SUBSCRIPTION, Optional.empty(), Optional.of("Gültig für 1 Jahr. Alle Geräte und Kurse inklusive.")));
            itemCatalog.save(new Item("2-Jahres-Abo", Money.of(25.00, EURO), ItemType.SUBSCRIPTION, Optional.empty(), Optional.of("Gültig für 2 Jahre. Alle Geräte und Kurse inklusive.")));
            itemCatalog.save(new Item("Frühaufsteher-Abo", Money.of(15.00, EURO), ItemType.SUBSCRIPTION, Optional.empty(), Optional.of("Gültig für 1 Jahr. Zugang nur von 5:00 bis 9:00 Uhr.")));
        }
    }
}
