package kickstart.catalog;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter; // Add import for DateTimeFormatter
import java.util.Optional;

import org.javamoney.moneta.Money;
import org.salespointframework.catalog.Product;

import jakarta.persistence.Entity;

@Entity
public class Item extends Product{
    
    //Unterteilung in verschiedene Produkttypen
    public static enum ItemType {
        FOOD, OTHERS, SUBSCRIPTION;
    }
    
    private ItemType type;
    private boolean isSubscription;
    private boolean isFood;

    private LocalDate expirationDate;
    private String subscriptionDetails;
    
    
    // Leerer Konstruktor für JPA
    @SuppressWarnings({"unused", "deprecation"})
    private Item() {}
    
    // Konstruktor
    public Item(String name, Money price, ItemType type, Optional <LocalDate> expirationDate, Optional <String> subscriptionDetails) {
        super(name, price);
        
        this.type = type;
        this.isFood = (type == ItemType.FOOD);
        this.isSubscription = (type == ItemType.SUBSCRIPTION);

        this.expirationDate = expirationDate.orElse(null);
        this.subscriptionDetails = subscriptionDetails.orElse(null);
    }

    // Type
    public ItemType getType() {
        return type;
    }

    public void setType(ItemType type) {
        this.type = type;
        if (type == ItemType.FOOD) {
            this.isFood = true;
            this.isSubscription = false;
        } 
        else if (type == ItemType.SUBSCRIPTION) {
            this.isSubscription = true;
            this.isFood = false;
        } 
        else {
            this.isFood = false;
            this.isSubscription = false;
        }
    }
    
    // Verfallsdatum (nur FOOD)
    public void setExpirationDate(LocalDate expirationDate) {
        this.expirationDate = expirationDate;
    }

    public Optional<LocalDate> getExpirationDate() {
        if (isFood == true){
            return Optional.ofNullable(expirationDate);
        }
        else{
            return Optional.empty();
        }
    }

    public String getExpirationDateAsString() {
        if (isFood && expirationDate != null) {
            DateTimeFormatter germanFormat = DateTimeFormatter.ofPattern("dd.MM.yyyy");
            return expirationDate.format(germanFormat);
        } else {
            return "-";
        }
    }

    // Details (nur SUBSCRIPTION)
    public void setSubscriptionDetails(String subscriptionDetails) {
        this.subscriptionDetails = subscriptionDetails;
    }

    public Optional<String> getSubscriptionDetails() {
        if (isSubscription == true){
            return Optional.ofNullable(subscriptionDetails);
        }
        else{
            return Optional.empty();
        }
    }

    public String getSubscriptionDetailsAsString() {
        if (isSubscription && subscriptionDetails != null) {
            return subscriptionDetails;
        } else {
            return "-";
        }
    }
}
