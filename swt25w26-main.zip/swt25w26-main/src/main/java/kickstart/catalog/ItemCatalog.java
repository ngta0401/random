package kickstart.catalog;

import org.salespointframework.catalog.Catalog;
import org.springframework.data.domain.Sort;
import org.springframework.data.util.Streamable;


public interface ItemCatalog extends Catalog<Item> {
    static final Sort DEFAULT_SORT = Sort.sort(Item.class).by(Item::getId).descending();

    Streamable<Item> findByType(Item.ItemType type, Sort sort);

    default Streamable<Item> findByType(Item.ItemType type) {
		return findByType(type, DEFAULT_SORT);
    }
}
