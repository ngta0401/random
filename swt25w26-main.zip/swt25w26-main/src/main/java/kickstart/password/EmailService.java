package kickstart.password;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {
	private final JavaMailSender javaMailSender;

	public EmailService(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}
	/**
	 * @param email email address.
	 * @param resetLink password reset link.
	 * @throws MailException if fails.
	 */
	public void sendPasswordResetEmail(String email, String resetLink) throws MailException {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom("thienanh.nguyen0401@gmail.com"); // Test with my email, replace later
		message.setTo(email);
		message.setSubject("ProFit - Passwort zurücksetzen");

		String emailBody = "Reset link: " + resetLink;
		message.setText(emailBody);
		javaMailSender.send(message);
	}
}
