package kickstart.password;

import org.salespointframework.useraccount.Password.UnencryptedPassword;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManagement;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.mail.MailException;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Controller
@Transactional
class PasswordResetController {
	private	final UserAccountManagement userAccountManagement;
	private final PasswordResetTokenRepository tokenRepository;
	private final EmailService emailService;

	public PasswordResetController(UserAccountManagement userAccountManagement,
								   PasswordResetTokenRepository tokenRepository,
								   EmailService emailService) {
		this.userAccountManagement = userAccountManagement;
		this.tokenRepository = tokenRepository;
		this.emailService = emailService;
	}

	// --Request user to submit username--

	@GetMapping("/password-reset")
	public String requestReset() {
		return "passwordreset";
	}

	@PostMapping("/password-reset")
	public String processRequest(@RequestParam("email") String email, Model model) {
		// Find the email
		System.out.println("DEBUG: Received request for email: " + email);
		Optional<UserAccount> userAccount = findUserByEmail(email);
		if (userAccount.isEmpty()) {
			System.out.println("DEBUG: No user found.");
		}
		userAccount.ifPresent(account -> {
			System.out.println("DEBUG: User " + account.getUsername()+ " found.");
			// if token already existed, delete it first
			Optional<PasswordResetToken> existingToken = tokenRepository.findByUserAccount(account);
			existingToken.ifPresent(token -> {
				System.out.println("DEBUG: Delete token for user: " + account.getEmail());
				tokenRepository.delete(token);
			});
			// then generate time limited token
			String token = UUID.randomUUID().toString();
			LocalDateTime expiryDate = LocalDateTime.now().plusHours(24);

			// Create and save token
			PasswordResetToken resetToken = new PasswordResetToken(token, account, expiryDate);
			tokenRepository.save(resetToken);

			// Send link to email
			String resetLink = "http://localhost:8080/password-reset/confirm?token=" + token;

			try {
				System.out.println("DEBUG: EmailService send link");
				emailService.sendPasswordResetEmail(email, resetLink);
				System.out.println("DEBUG: EmailService finished");
			} catch (MailException e) {
				System.err.println("Can't send reset password " + e.getMessage());
			}
		});
			model.addAttribute("message", "Ein Link wird gesendet, wenn der Benutzername in unserem System existiert.");
			return "passwordreset";
	}

	private Optional<UserAccount> findUserByEmail(String email) {
		if (email == null || email.isEmpty()) {
			return Optional.empty();
		}
		System.out.println("DEBUG: findUserByEmail: " + email);

		for (UserAccount user : userAccountManagement.findAll()) {
			System.out.println("DEBUG: findUserByEmail." + user.getUsername() + " | " + user.getEmail());
			if (email.equalsIgnoreCase(user.getEmail())) {
				System.out.println("DEBUG: match found");
				return Optional.of(user); // If found.
			}
		}
		System.out.println("DEBUG: findUserByEmail: no match");
		return Optional.empty(); // if there's no match in the database.
	}

	// --Confirmation
	@GetMapping("/password-reset/confirm")
	public String resetForm(@RequestParam("token") String token, Model model) {
		// Validate token
		Optional<PasswordResetToken> optToken = tokenRepository.findByToken(token);

		if (optToken.isEmpty() || optToken.get().isExpired()) {
			model.addAttribute("error", "Dieser Link ist nicht valid");
			return "passwordresetconfirm";
		}
		model.addAttribute("token", token);
		return "passwordresetconfirm";
	}

	// Process new password change
	@PostMapping("/password-reset/confirm")
	public String processReset(@RequestParam("token") String token,
							   @RequestParam("newPassword") String newPassword,
							   @RequestParam("confirmPassword") String confirmPassword,
							   Model model) {
		if (!newPassword.equals(confirmPassword)) {
			model.addAttribute("error", "Passwörter stimmen nicht überein!");
			model.addAttribute("token", token);
			return "passwordresetconfirm";
		}
		// Validate token
		Optional<PasswordResetToken> optToken = tokenRepository.findByToken(token);

		if (optToken.isEmpty() || optToken.get().isExpired()) {
			model.addAttribute("error",
				"Das Token ist fehlgeschlagen. Bitte fordern einen neuen Link an");
			return "passwordresetconfirm";
		}

		// If valid, get the user and change the password
		PasswordResetToken validToken = optToken.get();
		UserAccount userAccount = validToken.getUserAccount();

		// Change password with Salespoint
		userAccountManagement.changePassword(userAccount, UnencryptedPassword.of(newPassword));
		tokenRepository.delete(validToken);

		model.addAttribute("success", "Ihr Passwort wurde erfolgreich verändert!");
		return "login";
	}
}