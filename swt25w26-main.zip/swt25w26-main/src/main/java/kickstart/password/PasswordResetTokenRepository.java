package kickstart.password;
import org.salespointframework.useraccount.UserAccount;
import org.springframework.data.repository.CrudRepository;
import java.util.Optional;

public interface PasswordResetTokenRepository extends CrudRepository<PasswordResetToken, Long>{
	Optional<PasswordResetToken> findByToken(String token);
	// Find token tied to an account, to see if it is already existed for that user.
	Optional<PasswordResetToken> findByUserAccount(UserAccount userAccount);
}
