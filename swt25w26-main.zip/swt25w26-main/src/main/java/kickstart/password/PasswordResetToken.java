package kickstart.password;
import jakarta.persistence.*;
import org.salespointframework.useraccount.UserAccount;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
public class PasswordResetToken {

	@Id
	@GeneratedValue
	private Long id;

	@Column(nullable = false, unique = true)
	private String token;

	@OneToOne
	private UserAccount userAccount;

	@Column(nullable = false)
	private LocalDateTime expiryDate;

	// JPA constructor
	protected PasswordResetToken() {}

	public PasswordResetToken(String token, UserAccount userAccount, LocalDateTime expiryDate) {
		this.token = token;
		this.userAccount = userAccount;
		this.expiryDate = expiryDate;
	}

	public String getToken() {
		return token;
	}

	public UserAccount getUserAccount() {
		return userAccount;
	}

	public LocalDateTime getExpiryDate() {
		return expiryDate;
	}

	//  Check if token is expired
	public boolean isExpired() {
		return LocalDateTime.now().isAfter(expiryDate);
	}

}
