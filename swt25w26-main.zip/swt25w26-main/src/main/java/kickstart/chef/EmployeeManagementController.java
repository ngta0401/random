package kickstart.chef;

import kickstart.employee.Employee;
import kickstart.member.Member;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
public class EmployeeManagementController {

	private List<Employee> employees = new ArrayList<>(); // Liste anlegen in der die neue Mitarbeiter gespeichert werden sollen

	public EmployeeManagementController() { // Standart Mitarbeiter die immer in der Tabelle sind 
		employees.add(new Employee("MaxMustermann",44 ,1953 ));
		employees.add(new Employee("MarieMusterfrau", 21, 1912));
		employees.add(new Employee("EmilEmilmann",40 ,1910 ));
		employees.add(new Employee("Elisa Müller", 45, 1966));
		employees.add(new Employee("Ludwig Richter",50 ,1963 ));
		employees.add(new Employee("Luisa Kunze", 41, 1970));
	}

	@GetMapping("/employeemanagement") // Daten aus URL an http empfangen 
	public String listEmployees(@RequestParam(value = "editName", required = false) String editName, Model model){
		
		Employee newEmployee = new Employee();  // neue Variable vom Typ Employee 

		if (editName != null){                   // prüfe ob ein Name übergeben wurde
			for (Employee e : employees) {
				if (e.getName().equalsIgnoreCase(editName)) { // wenn es einen editNamen gibt prüfe ob dieser schon existiert 
					newEmployee = e;
				}
			}
		}

        model.addAttribute("employees", employees);  // übergabe der Mitarbeiterliste an html
		model.addAttribute("employeeForm", newEmployee); // übergabe der Mitarbeiter 
		
		return "employeemanagement";
	}

	@GetMapping("/editemployee")
	public String showEditEmployeeForm(@RequestParam("editName") String name, Model model) {

		Employee employeeToEdit = null;
		for (Employee e : employees) {
			if (e.getName().equalsIgnoreCase(name)) {
				employeeToEdit = e;
				break;
			}
		}

		if (employeeToEdit == null) {
			return "redirect:/employeemanagement";
		}

		model.addAttribute("employeeForm", employeeToEdit);
		return "editemployee";
	}

	@PostMapping("/editemployee")
	public String updateEmployee(@ModelAttribute("employeeForm") Employee editedEmployee) {

		for (int i = 0; i < employees.size(); i++) {
			if (employees.get(i).getName().equalsIgnoreCase(editedEmployee.getName())) {
				employees.set(i, editedEmployee);
				break;
			}
		}

		return "redirect:/employeemanagement";
	}

	@PostMapping("/employeemanagement/delete") // wird aufgerufen wenn der Mitarbeiter gelöscht werdern soll (nach Name)
	public String deleteEmployee (@RequestParam("deleteName") String deleteName) {

		employees.removeIf(e -> e.getName().equalsIgnoreCase(deleteName)); // Mitarbeiter wird entfernt
		
		return "redirect:/employeemanagement"; 
	}

	@GetMapping("/addemployee")
	public String showAddEmployeeForm(Model model) {
		model.addAttribute("employeeForm", new Employee());
		return "addemployee";
	}

	@PostMapping("/addemployee")
	public String addemployee(
			@RequestParam("name") String name,
			@RequestParam("age") int age,
			@RequestParam("salary") int salary) {

		Employee newEmployee = new Employee(name, age, salary);
		employees.add(newEmployee);

		return "redirect:/employeemanagement";
	}
}
