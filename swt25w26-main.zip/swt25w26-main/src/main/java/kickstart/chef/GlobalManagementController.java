package kickstart.chef;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class GlobalManagementController {
	@GetMapping("/globalmanagement")
	public String index() {
		return "globalmanagement";
	}
}
