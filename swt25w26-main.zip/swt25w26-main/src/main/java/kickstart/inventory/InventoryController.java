package kickstart.inventory;

import java.time.LocalDate;
import java.util.Optional;

import org.javamoney.moneta.Money;
import static org.salespointframework.core.Currencies.EURO;
import org.salespointframework.inventory.InventoryItem.InventoryItemIdentifier;
import org.salespointframework.inventory.UniqueInventory;
import org.salespointframework.inventory.UniqueInventoryItem;
import org.salespointframework.quantity.Quantity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kickstart.catalog.Item;
import kickstart.catalog.ItemCatalog;

@Controller
public class InventoryController {
    private final UniqueInventory<UniqueInventoryItem> inventory;
    private final ItemCatalog catalog;

    public InventoryController(UniqueInventory<UniqueInventoryItem> inventory, ItemCatalog catalog) {
        this.inventory = inventory;
        this.catalog = catalog;
    }

    // gesamten Stock anzeigen
    @GetMapping("/stock")
    String inventory(Model model) {
        model.addAttribute("stock", inventory.findAll());
        return "stock";
    }

    // zum "Artikel im Stock hinzufügen"-Formular
    @GetMapping("/additem")
    @PreAuthorize("hasAnyRole('CHEF', 'COUNTERSTAFF')")
    String inventoryEdit(Model model) {
        model.addAttribute("stock", inventory.findAll());
        return "additem";
    }

    // zum "Artikel im Stock bearbeiten"-Formular
    @GetMapping("/editItem")
    @PreAuthorize("hasAnyRole('CHEF', 'COUNTERSTAFF')")
    public String editItemForm(@RequestParam("itemId") String itemId, Model model) {
        var opInvItem = inventory.findById(InventoryItemIdentifier.of(itemId));
        if (opInvItem.isEmpty()) {
            return "redirect:/stock";
        }
        var invItem = opInvItem.get();
        model.addAttribute("item", invItem);
        return "edititem";
    }

    // Löschen bestätigen
    @GetMapping("/confirmDeleteItem")
    @PreAuthorize("hasAnyRole('CHEF', 'COUNTERSTAFF')")
    public String confirmDeleteItem(@RequestParam("itemId") String itemId, Model model) {
        var opInvItem = inventory.findById(InventoryItemIdentifier.of(itemId));
        if (opInvItem.isEmpty()) {
            return "redirect:/stock";
        }
        var invItem = opInvItem.get();
        model.addAttribute("item", invItem);
        return "/deleteItem";
    }

    // Artikel aus Stock (und Katalog) löschen
    @GetMapping("/deleteItem")
    @PreAuthorize("hasAnyRole('CHEF', 'COUNTERSTAFF')")
    public String deleteItem(@RequestParam("itemId") String itemId) {
        var opInvItem = inventory.findById(InventoryItemIdentifier.of(itemId));
        if (opInvItem.isPresent()) {
            var invitem = opInvItem.get();
            var catitem = (Item) invitem.getProduct();
            
            inventory.delete(invitem);
            catalog.delete(catitem);
        }
        return "redirect:/stock";
    }

    // Artikel in Stock bearbeiten und speichern
    @PostMapping("/updateItem")
    @PreAuthorize("hasAnyRole('CHEF', 'COUNTERSTAFF')")
    public String updateItem(
        @RequestParam("itemId") String itemId,
        @RequestParam("name") String name, 
        @RequestParam("price") Number price, 
        @RequestParam("type") String type,
        @RequestParam(required=false) LocalDate expirationDate,
        @RequestParam(required=false) String subscriptionDetails,
        @RequestParam("quantity") int quantity) {
            var opItem = inventory.findById(InventoryItemIdentifier.of(itemId));
            if (opItem.isEmpty()) {
                return "redirect:/stock";
            }
            var invitem = opItem.get();
            var catitem = (Item) invitem.getProduct();

            catitem.setName(name);
            catitem.setPrice(Money.of(price, EURO));
            catitem.setType(Item.ItemType.valueOf(type));
            catitem.setExpirationDate(expirationDate);
            catitem.setSubscriptionDetails(subscriptionDetails);
            catalog.save(catitem);

            var dif = Quantity.of(quantity).subtract(invitem.getQuantity());
            invitem.increaseQuantity(dif);

            inventory.save(invitem);

            return "redirect:/stock";
        }

    // Artikel zum Katalog und Stock hinzufügen
    @PostMapping("/addItem")
    @PreAuthorize("hasAnyRole('CHEF', 'COUNTERSTAFF')")
    public String addItem(
        @RequestParam("name") String name, 
        @RequestParam("price") Number price, 
        @RequestParam("type") String type,
        @RequestParam(required = false) LocalDate expirationDate,
        @RequestParam(required = false) String subscriptionDetails,
        @RequestParam(defaultValue = "0") int quantity) {
            Item item = new Item(name, Money.of(price, EURO), Item.ItemType.valueOf(type), Optional.ofNullable(expirationDate), Optional.ofNullable(subscriptionDetails));
            catalog.save(item);
            inventory.save(new UniqueInventoryItem(item, Quantity.of(quantity)));
                
            return "redirect:/stock";
    }

}