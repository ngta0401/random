package kickstart.inventory;

import org.salespointframework.core.DataInitializer;
import org.salespointframework.inventory.UniqueInventory;
import org.salespointframework.inventory.UniqueInventoryItem;
import org.salespointframework.quantity.Quantity;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import kickstart.catalog.ItemCatalog;

@Component
@Order(20)
public class InventoryInitializer implements DataInitializer {
    
    private final UniqueInventory<UniqueInventoryItem> inventory;
    private final ItemCatalog itemCatalog;

    public InventoryInitializer(UniqueInventory<UniqueInventoryItem> inventory, ItemCatalog itemCatalog) {
        Assert.notNull(inventory, "Inventory must not be null!");
        Assert.notNull(itemCatalog, "Catalog must not be null!");

        this.inventory = inventory;
        this.itemCatalog = itemCatalog;
    }

    @Override
    public void initialize() {
        if (inventory.findAll().iterator().hasNext()) {
            return;
        }

        itemCatalog.findAll().forEach(item -> {
            if (inventory.findByProduct(item).isEmpty()) {
				inventory.save(new UniqueInventoryItem(item, Quantity.of(10)));
			}
        });
    }
}