package kickstart.employee;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EmployeeController {
	@GetMapping("/employeeportal")
	public String index() {
		return "employeeportal";
	}

}
