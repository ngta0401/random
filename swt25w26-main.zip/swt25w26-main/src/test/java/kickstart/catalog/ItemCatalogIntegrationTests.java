package kickstart.catalog;

import kickstart.AbstractIntegrationTests;

public class ItemCatalogIntegrationTests extends AbstractIntegrationTests{
	
}
