/*package kickstart.member;

import static org.assertj.core.api.Assertions.*;

import kickstart.AbstractIntegrationTests;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;

class MemberPCIntegrationTests extends AbstractIntegrationTests {

    @Autowired MemberPortalController controller;

    @Test
    @SuppressWarnings("unchecked")
    public void rendersMemberPCView() {

        Model model = new ExtendedModelMap();
        String viewName = controller.index();

        assertThat(viewName).isEqualTo("memberportal");
    }
}*/