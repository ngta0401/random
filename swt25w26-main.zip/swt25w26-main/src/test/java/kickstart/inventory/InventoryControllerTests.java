package kickstart.inventory;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import org.javamoney.moneta.Money;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.Mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.salespointframework.inventory.UniqueInventory;
import org.salespointframework.inventory.UniqueInventoryItem;
import org.salespointframework.quantity.Quantity;
import java.time.LocalDate;

import kickstart.catalog.Item;
import kickstart.catalog.ItemCatalog;

@ExtendWith(MockitoExtension.class)
public class InventoryControllerTests {

    @Mock UniqueInventory<UniqueInventoryItem> inventory;
    @Mock ItemCatalog catalog;

/*
    @Test
    void updateQuantityTest_existingItemIncreasesQuantity_shouldIncreaseQuantity() {

        var product = new Item("Apfel", Money.of(5.0, "EUR"), Item.ItemType.FOOD);
        UniqueInventoryItem item = new UniqueInventoryItem(product, Quantity.of(10));
        when(inventory.findById(item.getId())).thenReturn(Optional.of(item));
        
    //    var c = new InventoryController(inventory);
    //    c.updateQuantity(item.getId().toString(), 20);

        assertThat(item.getQuantity()).isEqualTo(Quantity.of(20));
    }
*/

    @Test
    void addItemTest_newItem_shouldAddItem() {
        var c = new InventoryController(inventory, catalog);
        c.addItem("Birne", 3, "FOOD", LocalDate.of(2025, 12, 31), null, 15);
        
        ArgumentCaptor<UniqueInventoryItem> inventoryCaptor = ArgumentCaptor.forClass(UniqueInventoryItem.class);
        verify(inventory).save(inventoryCaptor.capture());

        UniqueInventoryItem savedItem = inventoryCaptor.getValue();
        assertThat(savedItem.getQuantity()).isEqualTo(Quantity.of(15));
        
        Item product = (Item) savedItem.getProduct();
        assertThat(product.getName()).isEqualTo("Birne");
        assertThat(product.getPrice()).isEqualTo(Money.of(3, "EUR"));
        assertThat(product.getType()).isEqualTo(Item.ItemType.FOOD);
    }

    @Test
    void updateItemTest_existingItem_shouldUpdateItem() {
        var product = new Item("Birne", Money.of(3, "EUR"), Item.ItemType.FOOD, Optional.ofNullable(LocalDate.of(2025, 12, 31)), Optional.ofNullable(null));
        UniqueInventoryItem invitem = new UniqueInventoryItem(product, Quantity.of(15));
        when(inventory.findById(invitem.getId())).thenReturn(Optional.of(invitem));

        var c = new InventoryController(inventory, catalog);
        c.updateItem(invitem.getId().toString(), "Birne", 4, "OTHERS", null, null, 1);

        Item updatedProduct = (Item) invitem.getProduct();
        assertThat(updatedProduct.getName()).isEqualTo("Birne");
        assertThat(updatedProduct.getPrice()).isEqualTo(Money.of(4, "EUR"));
        assertThat(updatedProduct.getType()).isEqualTo(Item.ItemType.OTHERS);
        assertThat(invitem.getQuantity()).isEqualTo(Quantity.of(1));
    }

    @Test
    void deleteItemTest_existingItem_shouldDeleteItem() {
        var product = new Item("Birne", Money.of(3, "EUR"), Item.ItemType.FOOD, Optional.ofNullable(LocalDate.of(2025, 12, 31)), Optional.ofNullable(null));
        UniqueInventoryItem invitem = new UniqueInventoryItem(product, Quantity.of(15));
        when(inventory.findById(invitem.getId())).thenReturn(Optional.of(invitem));

        var c = new InventoryController(inventory, catalog);
        c.deleteItem(invitem.getId().toString());

        verify(inventory).delete(invitem);
        verify(catalog).delete(product);
    }

    @Test
    void deleteItemTest_nonExistingItem_shouldNotDeleteItem() {
        var c = new InventoryController(inventory, catalog);
        c.deleteItem("12345");
        verify(inventory, never()).delete(any());
    }
}
