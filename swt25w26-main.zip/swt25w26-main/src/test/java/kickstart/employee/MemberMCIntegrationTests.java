/*package kickstart.employee;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import kickstart.AbstractIntegrationTests;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import kickstart.member.Member; 

@SpringBootTest 
@AutoConfigureMockMvc 
class MemberMCIntegrationTests extends AbstractIntegrationTests {

    @Autowired
    MockMvc mockMvc; 

    @Test //Sollte Die Mitglieder Liste Anzeigen
    void listMemberstest() throws Exception {
        mockMvc.perform(get("/membermanagement"))
                .andExpect(status().isOk()) 
                .andExpect(view().name("membermanagement")) // Erwartet die View "employeemanagement"
                // Prüft, ob die Liste "members" im Model ist und mindestens 2 Elemente hat (MaxMustermann, MarieMusterfrau)
                .andExpect(model().attributeExists("members"))
                .andExpect(model().attribute("members", org.hamcrest.Matchers.hasSize(2))); 
    }

    @Test //Sollte Form Mit Neuem Mitglied Anzeigen
    void listMemberstest2() throws Exception {
        mockMvc.perform(get("/membermanagement"))
                .andExpect(model().attributeExists("memberForm"))
                // Prüft, ob ein neues Member-Objekt ohne Namen im Model ist
                .andExpect(model().attribute("memberForm", org.hamcrest.Matchers.hasProperty("name", org.hamcrest.Matchers.nullValue())));
    }
    
    @Test //Sollte Form Mit Existierendem Mitglied Anzeigen
    void listMemberstest3() throws Exception {
        mockMvc.perform(get("/membermanagement")
                .param("editName", "MaxMustermann")) // Parameter 'editName' setzen
                .andExpect(status().isOk())
                .andExpect(view().name("membermanagement"))
                // Prüft, ob das im Model enthaltene memberForm-Objekt den Namen "MaxMustermann" hat
                .andExpect(model().attribute("memberForm", org.hamcrest.Matchers.hasProperty("name", org.hamcrest.Matchers.equalTo("MaxMustermann"))));
    }


    // -------------------------------------------------------------------------

    @Test //Sollte Neues Mitglied Hinzufügen
    void saveMembertest() throws Exception {
        // Neues Mitglied anlegen:
        mockMvc.perform(post("/membermanagement")
                .param("name", "NeuerMann")
                .param("birthyear", "1930")
                .param("email", "2020"))
                .andExpect(status().is3xxRedirection()) // Erwartet Weiterleitung (redirect)
                .andExpect(redirectedUrl("/membermanagement"));

        // Überprüfe, ob das Mitglied jetzt in der Liste ist (indirekt über GET-Request):
        mockMvc.perform(get("/membermanagement"))
                // Die Liste sollte jetzt 3 Elemente haben (MaxMustermann, MarieMusterfrau, NeuerMann)
                .andExpect(model().attribute("members", org.hamcrest.Matchers.hasSize(3))); 
    }

    @Test //Sollte Existierendes Mitglied Aktualisieren
    void saveMembertest2() throws Exception {
        // Aktualisieren des Mitglieds "MaxMustermann":
        mockMvc.perform(post("/membermanagement")
                .param("name", "MaxMustermann") // Name muss gleich bleiben, damit die Logik den Mitarbeiter findet
                .param("birthyear", "1950") // Jahre ändern sich
                .param("email", "Dresden@gmail.com"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/membermanagement"));

        // Überprüfe, ob die Aktualisierung gespeichert wurde (indirekt über edit-Aufruf):
        mockMvc.perform(get("/membermanagement")
                .param("editName", "MaxMustermann")) // Parameter 'editName' setzen
                // Prüft, ob das aktualisierte Member-Objekt im Model ist (Alter = 50)
                .andExpect(model().attribute("memberForm", org.hamcrest.Matchers.hasProperty("birthyear", org.hamcrest.Matchers.equalTo(1950))));
    }
    // -------------------------------------------------------------------------
    @Test //Sollte Mitglied Entfernen
    void deleteMembertests() throws Exception {
        // Mitglied "MarieMusterfrau" löschen:
        mockMvc.perform(post("/membermanagement/delete")
                .param("deleteName", "MarieMusterfrau"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/membermanagement"));

        // Überprüfe, ob das Mitglied entfernt wurde:
        mockMvc.perform(get("/membermanagement"))
                // Die Liste sollte jetzt nur noch 1 Element haben (MaxMustermann)
                .andExpect(model().attribute("members", org.hamcrest.Matchers.hasSize(2))); 
    }
}*/