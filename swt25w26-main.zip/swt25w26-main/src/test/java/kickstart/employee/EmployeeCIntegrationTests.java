/*package kickstart.employee;

import static org.assertj.core.api.Assertions.*;

import kickstart.AbstractIntegrationTests;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;

class EmployeeCIntegrationTests extends AbstractIntegrationTests {

    @Autowired EmployeeController controller;

    @Test
    @SuppressWarnings("unchecked")
    public void rendersEmployeeCView() {

        Model model = new ExtendedModelMap();
        String viewName = controller.index();

        assertThat(viewName).isEqualTo("employeeportal");
    }
}*/ 