/*package kickstart.chef;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import kickstart.AbstractIntegrationTests;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import kickstart.employee.Employee; 

@SpringBootTest 
@AutoConfigureMockMvc 
class EmployeeMCIntegrationTests extends AbstractIntegrationTests {

    @Autowired
    MockMvc mockMvc; 

    @Test //Sollte Die Mitarbeiter Liste Anzeigen
    void listEmployeestest() throws Exception {
        mockMvc.perform(get("/employeemanagement"))
                .andExpect(status().isOk()) 
                .andExpect(view().name("employeemanagement")) // Erwartet die View "employeemanagement"
                // Prüft, ob die Liste "employees" im Model ist und mindestens 2 Elemente hat (MaxMustermann, MarieMusterfrau)
                .andExpect(model().attributeExists("employees"))
                .andExpect(model().attribute("employees", org.hamcrest.Matchers.hasSize(2))); 
    }

    @Test //Sollte Form Mit Neuem Mitarbeiter Anzeigen
    void listEmployeestest2() throws Exception {
        mockMvc.perform(get("/employeemanagement"))
                .andExpect(model().attributeExists("employeeForm"))
                // Prüft, ob ein neues Employee-Objekt ohne Namen im Model ist
                .andExpect(model().attribute("employeeForm", org.hamcrest.Matchers.hasProperty("name", org.hamcrest.Matchers.nullValue())));
    }
    
    @Test //Sollte Form Mit Existierendem Mitarbeiter Anzeigen
    void listEmployeestest3() throws Exception {
        mockMvc.perform(get("/employeemanagement")
                .param("editName", "MaxMustermann")) // Parameter 'editName' setzen
                .andExpect(status().isOk())
                .andExpect(view().name("employeemanagement"))
                // Prüft, ob das im Model enthaltene employeeForm-Objekt den Namen "MaxMustermann" hat
                .andExpect(model().attribute("employeeForm", org.hamcrest.Matchers.hasProperty("name", org.hamcrest.Matchers.equalTo("MaxMustermann"))));
    }


    // -------------------------------------------------------------------------

    @Test //Sollte Neuen Mitarbeiter Hinzufügen
    void saveEmployeetest() throws Exception {
        // Neuen Mitarbeiter anlegen:
        mockMvc.perform(post("/employeemanagement")
                .param("name", "NeuerMann")
                .param("age", "30")
                .param("salary", "2020"))
                .andExpect(status().is3xxRedirection()) // Erwartet Weiterleitung (redirect)
                .andExpect(redirectedUrl("/employeemanagement"));

        // Überprüfe, ob der Mitarbeiter jetzt in der Liste ist (indirekt über GET-Request):
        mockMvc.perform(get("/employeemanagement"))
                // Die Liste sollte jetzt 3 Elemente haben (MaxMustermann, MarieMusterfrau, NeuerMann)
                .andExpect(model().attribute("employees", org.hamcrest.Matchers.hasSize(3))); 
    }

    @Test //Sollte Existierenden Mitarbeiter Aktualisieren
    void saveEmployeetest2() throws Exception {
        // Aktualisiere den Mitarbeiter "MaxMustermann":
        mockMvc.perform(post("/employeemanagement")
                .param("name", "MaxMustermann") // Name muss gleich bleiben, damit die Logik den Mitarbeiter findet
                .param("age", "50") // Jahre ändern sich
                .param("salary", "1953"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/employeemanagement"));

        // Überprüfe, ob die Aktualisierung gespeichert wurde (indirekt über edit-Aufruf):
        mockMvc.perform(get("/employeemanagement")
                .param("editName", "MaxMustermann"))
                // Prüft, ob das aktualisierte Employee-Objekt im Model ist (Alter = 50)
                .andExpect(model().attribute("employeeForm", org.hamcrest.Matchers.hasProperty("age", org.hamcrest.Matchers.equalTo(50))));
    }
    // -------------------------------------------------------------------------
    @Test //Sollte Mitarbeiter Entfernen
    void deleteEmployeetest() throws Exception {
        // Mitarbeiter "MarieMusterfrau" löschen:
        mockMvc.perform(post("/employeemanagement/delete")
                .param("deleteName", "MarieMusterfrau"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/employeemanagement"));

        // Überprüfe, ob der Mitarbeiter entfernt wurde (indirekt über GET-Request):
        mockMvc.perform(get("/employeemanagement"))
                // Die Liste sollte jetzt nur noch 1 Element haben (MaxMustermann)
                .andExpect(model().attribute("employees", org.hamcrest.Matchers.hasSize(2))); 
    }
}*/