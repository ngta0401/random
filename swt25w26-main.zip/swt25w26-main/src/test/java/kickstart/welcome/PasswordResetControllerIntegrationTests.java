package kickstart.welcome;
import static org.hamcrest.CoreMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import kickstart.password.PasswordResetToken;
import kickstart.password.PasswordResetTokenRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManagement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.StreamSupport;

import java.time.LocalDateTime;
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
public class PasswordResetControllerIntegrationTests {
	@Autowired MockMvc mvc;
	//Check the database state
	@Autowired UserAccountManagement userAccountManagement;
	@Autowired PasswordResetTokenRepository tokenRepository;

	@Test
	void showsPasswordRequestForm() throws Exception {
		mvc.perform(get("/password-reset"))
			.andExpect(status().isOk())
			.andExpect(view().name("passwordreset"))
			.andExpect(content().string(containsString("Benutzername")));
	}

	@Test
	void processesPasswordRequest() throws Exception {
		String userEmail = "boss@profit.de";
		UserAccount user = userAccountManagement.findByUsername("boss").get();
		Assertions.assertEquals(userEmail, user.getEmail());

		// Send password reset request, check if controller actually adds that message
		mvc.perform(post("/password-reset")
				.param("email", userEmail))
				.andExpect(status().isOk())
				.andExpect(view().name("passwordreset"))
				.andExpect(model().attribute("message", containsString("Ein Link wird gesendet, wenn der Benutzername in unserem System existiert")));

		// Check the database, confirm if a token is created and saved, then if it linked to the boss
		var tokens = tokenRepository.findAll();
		List<PasswordResetToken> tokenList = StreamSupport
			.stream(tokens.spliterator(), false)
			.toList();
		Assertions.assertEquals(1, tokenList.size());
		Assertions.assertEquals("boss", tokenList.getFirst().getUserAccount().getUsername());

	}

}
